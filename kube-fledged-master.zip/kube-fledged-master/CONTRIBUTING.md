## We invite contributions to _kube-fledged_. 

- Submit an issue if you find a bug or interested in seeing a new feature implemented.
- If you would like to work on an existing issue, please make a comment in the issue.
- Upon Author's confirmation, start working on the issue.
- Fork the project, develop and test your code.
- Submit a pull request. Ensure ALL CI checks are passed.
- We will review and approve your pull request
