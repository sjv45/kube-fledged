## Kube-fledged Community Code of Conduct 

Kube-fledged follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md).

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting
the **Kube-fledged Code of Conduct Committee** via <kubefledged.codeofconduct@gmail.com>.
